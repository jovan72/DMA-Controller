/*
 * main.h
 *
 *  Created on: 05.2.2017
 *      Author: PC
 */

#ifndef MAIN_H_
#define MAIN_H_

#define EqualArray		1
#define DifferentArray	2

#define LOW				0
#define HIGH			1

/*--------------------------------------------------------*/

/* Initialize channel 0 for transmission of data from memory to memory	*/

/* Param[uint32_t] Source: Source of transmission */

/* Param[int] Size: Size of data to be transmitted	*/

/*--------------------------------------------------------*/

void GPDMA_ChannelInit(uint32_t Source, int Size);

/*--------------------------------------------------------*/

/* Function copy 4 byte array to 1 byte array	*/

/* Param[uint8_t] *ByteArray: pointer to the 1 byte array */

/* Param[uint32_t] *FourByte_Array: pointer to the 4 byte array	*/

/* Param[int] FourByteArraySize: Size of the 4 byte array	*/

/*--------------------------------------------------------*/

void CopyArrayTo_SmallerArray(uint8_t *ByteArray, uint32_t *FourByte_Array, int FourByteArraySize);

/*--------------------------------------------------------*/

/* Calculate the hash value for the given array	*/

/* Param[uint8_t] hash_destination Pointer to the array to be hashed*/

/* Param[uint32_t] data_size: Size of data to be hashed from the array	*/

/*--------------------------------------------------------*/

void Hash_Calculate(uint8_t* hash_destination, uint32_t data_size);

/*--------------------------------------------------------*/

/* Copy data of Array 1 in Array 2*/

/* Param[uint8_t] Arr1 Pointer to the byte array to be copied */

/* Param[uint8_t] Arr2 Pointer to the byte array to be saved data in it	*/

/* Param[int] Size: number of bytes to copied	*/

/*--------------------------------------------------------*/

void CopyCharArray_ToCharArray(uint8_t *Arr1, uint8_t *Arr2,int Size);

/*--------------------------------------------------------*/

/* Read data in a memory location using DMA and save it DMADest_Buffer	*/

/* Param[uint32_t] Source: Location of the Source in the memory*/

/* Param[int] Size: Number of bytes to be transfered	*/

/*--------------------------------------------------------*/

void DMA_ReadData(uint32_t Source, int Size);

/*--------------------------------------------------------*/

/* Wait for the DMA transmission to be completed	*/

/*--------------------------------------------------------*/

void DMA_Wait_Transmission(void);

/*--------------------------------------------------------*/

/* Compares two arrays of one byte and return if they are equal or not	*/

/* Param[uint8_t] Arr1 Pointer to the byte array to be compared */

/* Param[uint8_t] Arr2 Pointer to the second byte array to be compared	*/

/* Param[int] Size: Number of bytes to be compared*/

/* Param[uint8_t] CompareTwoArrays: return value = EqualArray or DifferentArray	*/

/*--------------------------------------------------------*/

uint8_t CompareTwoArrays(uint8_t *Arr1 , uint8_t *Arr2 , int Size);


#endif /* MAIN_H_ */
